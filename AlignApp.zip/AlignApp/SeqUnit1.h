//---------------------------------------------------------------------------

#ifndef SeqUnit1H
#define SeqUnit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TStringGrid *StringGrid1;
        TBitBtn *BitBtn1;
        TBitBtn *BitBtn2;
        TImage *Image1;
        TEdit *Edit1;
        TStringGrid *StringGrid2;
        TEdit *Edit2;
        TBitBtn *BitBtn4;
        TBitBtn *BitBtn5;
        TBitBtn *BitBtn6;
        TEdit *Edit3;
        TBitBtn *BitBtn9;
        TBitBtn *BitBtn11;
        TBitBtn *BitBtn13;
        TStringGrid *StringGrid3;
        TBitBtn *BitBtn15;
        TBitBtn *BitBtn16;
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall BitBtn2Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall BitBtn4Click(TObject *Sender);
        void __fastcall BitBtn5Click(TObject *Sender);
        void __fastcall Image1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall BitBtn6Click(TObject *Sender);
        void __fastcall BitBtn9Click(TObject *Sender);
        void __fastcall BitBtn11Click(TObject *Sender);
        void __fastcall Image1DblClick(TObject *Sender);
        void __fastcall BitBtn13Click(TObject *Sender);
        void __fastcall FormDblClick(TObject *Sender);
        void __fastcall BitBtn15Click(TObject *Sender);
        void __fastcall BitBtn16Click(TObject *Sender);
        void __fastcall FormClick(TObject *Sender);
        void __fastcall StringGrid3DblClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
