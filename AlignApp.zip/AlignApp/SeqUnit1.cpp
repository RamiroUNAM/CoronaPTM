#include <vcl.h>
#pragma hdrstop
#include "SeqUnit1.h"
#pragma package(smart_init)
#pragma resource "*.dfm"
#include "math.h"


TForm1 *Form1;


__fastcall TForm1::TForm1(TComponent* Owner):TForm(Owner)
{
}

void cleargrid1()
{
 int i,j;
 for(j=0;j<Form1->StringGrid1->RowCount;j++)
 {
  for(i=0;i<Form1->StringGrid1->ColCount;i++)
  {
   Form1->StringGrid1->Cells[i][j]="";
  }
 }
 Form1->StringGrid1->ColCount=1;
 Form1->StringGrid1->RowCount=1;
 Form1->StringGrid1->DefaultColWidth=15;
 Form1->StringGrid1->DefaultRowHeight=15;
 Form1->StringGrid1->ColWidths[0]=100;
}

void cleargrid2()
{
 int i,j;
 for(j=0;j<Form1->StringGrid2->RowCount;j++)
 {
  for(i=0;i<Form1->StringGrid2->ColCount;i++)
  {
   Form1->StringGrid2->Cells[i][j]="";
  }
 }
 Form1->StringGrid2->ColCount=1;
 Form1->StringGrid2->RowCount=1;
 Form1->StringGrid2->DefaultColWidth=15;
 Form1->StringGrid2->DefaultRowHeight=15;
}

void cleargrid3()
{
 int i,j;
 for(j=0;j<Form1->StringGrid3->RowCount;j++)
 {
  for(i=0;i<Form1->StringGrid3->ColCount;i++)
  {
   Form1->StringGrid3->Cells[i][j]="";
  }
 }
 Form1->StringGrid3->ColCount=1;
 Form1->StringGrid3->RowCount=1;
 Form1->StringGrid3->DefaultColWidth=60;
 Form1->StringGrid3->DefaultRowHeight=15;
}

void sortgrid2()
{
 int i,j;
 AnsiString s1,s2,s3;
 for(i=0;i<Form1->StringGrid2->RowCount-1;i++)
 {
  for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
  {
   if(Form1->StringGrid2->Cells[1][j].ToDouble()<Form1->StringGrid2->Cells[1][i].ToDouble())
   {
    s1=Form1->StringGrid2->Cells[0][i];
    s2=Form1->StringGrid2->Cells[1][i];
    s3=Form1->StringGrid2->Cells[2][i];
    Form1->StringGrid2->Cells[0][i]=Form1->StringGrid2->Cells[0][j];
    Form1->StringGrid2->Cells[1][i]=Form1->StringGrid2->Cells[1][j];
    Form1->StringGrid2->Cells[2][i]=Form1->StringGrid2->Cells[2][j];
    Form1->StringGrid2->Cells[0][j]=s1;
    Form1->StringGrid2->Cells[1][j]=s2;
    Form1->StringGrid2->Cells[2][j]=s3;
   }
  }
 }
}

void sortgrid3()
{
 int i,j;
 AnsiString s1,s2;
 for(i=0;i<Form1->StringGrid3->RowCount-1;i++)
 {
  for(j=0;j<Form1->StringGrid3->RowCount-1;j++)
  {
   if(Form1->StringGrid3->Cells[1][j].ToDouble()<Form1->StringGrid3->Cells[1][i].ToDouble())
   {
    s1=Form1->StringGrid3->Cells[0][i];
    s2=Form1->StringGrid3->Cells[1][i];
    Form1->StringGrid3->Cells[0][i]=Form1->StringGrid3->Cells[0][j];
    Form1->StringGrid3->Cells[1][i]=Form1->StringGrid3->Cells[1][j];
    Form1->StringGrid3->Cells[0][j]=s1;
    Form1->StringGrid3->Cells[1][j]=s2;
   }
  }
 }
}

void readalign()
{
 int i,j,k,count1,count2,count3,row,flag,gap;
 AnsiString s,t,id;

 cleargrid1();
 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 Form1->Memo1->Lines->LoadFromFile("Align"+Form1->Edit1->Text+".txt");

 count1=0;
 count2=0;
 for(j=1;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];
  if((s=="")||(s!="" && s[1]==' '))
  {
   count1++;
  }
  else
  {
   count2++;
  }
 }
 Form1->StringGrid1->ColCount=((count1/2)*60)+1;
 Form1->StringGrid1->RowCount=(count2/(count1/2));

 for(j=1;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];

  if((s=="")||(s!="" && s[1]==' '))
  {
   row=-1;
  }

  else
  {
   row++;

   i=1;
   id="";
   while(s[i]!=' ')
   {
    id=id+s[i];
    i++;
   }
   while(s[i]==' ')
   {
    i++;
   }
   t="";
   while(s[i]!=' ' && i<s.Length())
   {
    t=t+s[i];
    i++;
   }
   if(i==s.Length())
   {
    t=t+s[i];
   }

   i=1;
   while(Form1->StringGrid1->Cells[i][row]!="")
   {
    i++;
   }

   for(k=1;k<t.Length()+1;k++)
   {
    Form1->StringGrid1->Cells[i][row]=t[k];
    i++;
   }
   Form1->StringGrid1->Cells[0][row]=id;

  }

 }

 cleargrid2();
 Form1->StringGrid2->ColCount=2;
 Form1->StringGrid2->RowCount=6;
 Form1->StringGrid2->DefaultColWidth=200;
 count1=0;
 count2=0;
 count3=0;
 for(i=1;i<Form1->StringGrid1->ColCount;i++)
 {
  gap=0;
  s=Form1->StringGrid1->Cells[i][0];
  if(s!="")
  {
   if(s=="-")
   {
    gap=1;
   }
   flag=0;
   for(j=1;j<Form1->StringGrid1->RowCount;j++)
   {
    if(Form1->StringGrid1->Cells[i][j]!=s)
    {
     flag=1;
    }
    if(Form1->StringGrid1->Cells[i][j]=="-")
    {
     gap=1;
    }
   }
   if(flag==0)
   {
    count1++;
   }
   else
   {
    count2++;
   }
   if(gap==1)
   {
    count3++;
   }
  }
 }
 Form1->StringGrid2->Cells[0][0]="Species";
 Form1->StringGrid2->Cells[0][1]="Length";
 Form1->StringGrid2->Cells[0][2]="Conserved";
 Form1->StringGrid2->Cells[0][3]="Non Conserved";
 Form1->StringGrid2->Cells[0][4]="Homologous";
 Form1->StringGrid2->Cells[1][0]=Form1->StringGrid1->RowCount;
 Form1->StringGrid2->Cells[1][1]=count1+count2;
 Form1->StringGrid2->Cells[1][2]=count1;
 Form1->StringGrid2->Cells[1][3]=count2;
 Form1->StringGrid2->Cells[1][4]=(count1+count2)-count3;

}

void readptms()
{
 int i,j,k;
 char c;
 AnsiString s,t;

 cleargrid2();

 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 Form1->Memo1->Lines->LoadFromFile("PTM"+Form1->Edit2->Text+".txt");
 c=';';
 s=Form1->Memo1->Lines->Strings[0];
 for(i=1;i<s.Length();i++)
 {
  if(s[i]==c)
  {
   Form1->StringGrid2->ColCount++;
  }
 }
 for(j=0;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];
  t="";
  k=0;
  for(i=1;i<s.Length()+1;i++)
  {
   if(s[i]!=c)
   {
    t=t+s[i];
   }
   else
   {
    Form1->StringGrid2->Cells[k][Form1->StringGrid2->RowCount-1]=t;
    k++;
    t="";
   }
  }
  Form1->StringGrid2->Cells[k][Form1->StringGrid2->RowCount-1]=t;
  Form1->StringGrid2->RowCount++;
 }
 s=Form1->StringGrid2->RowCount-2;
 Form1->StringGrid2->Cells[0][Form1->StringGrid2->RowCount-1]=" Records = "+s;
 Form1->StringGrid2->Col=1;
 Form1->StringGrid2->Row=Form1->StringGrid2->RowCount-1;

 Form1->StringGrid2->ColCount=Form1->StringGrid2->ColCount+3;
 Form1->StringGrid2->DefaultColWidth=50;
 Form1->StringGrid2->ColWidths[0]=150;
 Form1->StringGrid2->ColWidths[3]=150;

}

void mapping()
{
 int i,j,k,p,count,m1,m2,sites,flag;
 AnsiString id,aa,ptm;

 m1=0;
 m2=0;
 for(j=1;j<Form1->StringGrid2->RowCount-1;j++)
 {
  id=Form1->StringGrid2->Cells[0][j];
  p=Form1->StringGrid2->Cells[1][j].ToInt();
  aa=Form1->StringGrid2->Cells[2][j];
  ptm=Form1->StringGrid2->Cells[3][j];
  for(i=0;i<Form1->StringGrid1->RowCount;i++)
  {
   if(Form1->StringGrid1->Cells[0][i]==id)
   {
    count=0;
    k=0;
    do
    {
     k++;
     if(Form1->StringGrid1->Cells[k][i]!="-")
     {
      count++;
     }
    }
    while(count!=p);

    if(Form1->StringGrid1->Cells[k][i]==aa)
    {
     Form1->StringGrid1->Cells[k][i]=Form1->StringGrid1->Cells[k][i]+"+"+ptm;
     Form1->StringGrid2->Cells[4][j]="1";
     m1++;
    }
    else
    {
     Form1->StringGrid2->Cells[5][j]="X";
     m2++;
    }
   }
  }
 }

 sites=0;
 for(i=1;i<Form1->StringGrid1->ColCount;i++)
 {
  flag=0;
  for(j=0;j<Form1->StringGrid1->RowCount;j++)
  {
   if(Form1->StringGrid1->Cells[i][j].Length()>1)
   {
    flag=1;
   }
  }
  if(flag==1)
  {
   sites++;
  }
 }

 Form1->StringGrid2->Cells[3][Form1->StringGrid2->RowCount-1]=" Mapping :";
 Form1->StringGrid2->Cells[4][Form1->StringGrid2->RowCount-1]=m1;
 Form1->StringGrid2->Cells[5][Form1->StringGrid2->RowCount-1]=m2;
 Form1->StringGrid2->Cells[6][Form1->StringGrid2->RowCount-1]=sites;

 Form1->StringGrid2->Col=1;
 Form1->StringGrid2->Row=Form1->StringGrid2->RowCount-1;
 Form1->StringGrid1->DefaultColWidth=35;
 Form1->StringGrid1->ColWidths[0]=100;

}

void propagate()
{
 int i,j,k,p;
 AnsiString s,aa,ptm;

 for(i=1;i<Form1->StringGrid1->ColCount;i++)
 {
  for(j=0;j<Form1->StringGrid1->RowCount;j++)
  {
   s=Form1->StringGrid1->Cells[i][j];

   if(s.Length()>1 && s[2]=='+')
   {
    aa=s[1];
    ptm="";
    for(p=3;p<s.Length()+1;p++)
    {
     ptm=ptm+s[p];
    }
    for(k=0;k<Form1->StringGrid1->RowCount;k++)
    {

     if(Form1->StringGrid1->Cells[i][k]==aa)
     {
      Form1->StringGrid1->Cells[i][k]=Form1->StringGrid1->Cells[i][k]+"-"+ptm;
     }
     else
     {
      if(Form1->Edit3->Text!="0")
      {
       if(ptm=="Phosphorylation" && (Form1->StringGrid1->Cells[i][k]=="S" || Form1->StringGrid1->Cells[i][k]=="T" || Form1->StringGrid1->Cells[i][k]=="Y"))
       {
        Form1->StringGrid1->Cells[i][k]=Form1->StringGrid1->Cells[i][k]+"-"+ptm;
       }
       if(ptm=="O-GalNAc" && (Form1->StringGrid1->Cells[i][k]=="S" || Form1->StringGrid1->Cells[i][k]=="T"))
       {
        Form1->StringGrid1->Cells[i][k]=Form1->StringGrid1->Cells[i][k]+"-"+ptm;
       }
       if(ptm=="Phosphorylation_O-GalNAc" && (Form1->StringGrid1->Cells[i][k]=="S" || Form1->StringGrid1->Cells[i][k]=="T"))
       {
        Form1->StringGrid1->Cells[i][k]=Form1->StringGrid1->Cells[i][k]+"-"+ptm;
       }
       if(ptm=="Methylation" && (Form1->StringGrid1->Cells[i][k]=="E" || Form1->StringGrid1->Cells[i][k]=="R" || Form1->StringGrid1->Cells[i][k]=="K"))
       {
        Form1->StringGrid1->Cells[i][k]=Form1->StringGrid1->Cells[i][k]+"-"+ptm;
       }
      }
     }

    }
   }
  }
 }

}

void readregion(int n)
{
 int i,j,k,count,col;
 char c;
 AnsiString s,t,id,xi,xu,name,file;

 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 if(n==1)
 {
  file="_DOMAIN.txt";
  col=9;
 }
 if(n==2)
 {
  file="_IDR.txt";
  col=11;
 }
 Form1->Memo1->Lines->LoadFromFile(file);

 c=';';
 for(j=0;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];
  t="";
  count=0;
  for(i=1;i<s.Length()+1;i++)
  {
   if(s[i]!=c)
   {
    t=t+s[i];
   }
   else
   {
    count++;
    if(count==1)
    {
     id=t;
    }
    if(count==3)
    {
     xi=t;
    }
    if(count==4)
    {
     xu=t;
    }
    t="";
   }
  }
  name=t;

  if(id==Form1->StringGrid1->Cells[0][Form1->StringGrid1->Row])
  {
   for(k=xi.ToInt()-1;k<xu.ToInt();k++)
   {
    Form1->StringGrid2->Cells[col][k]=name;
   }
  }

 }

}

void read2d()
{
 int i,j,k,count;
 char c;
 AnsiString s,t,id,xi,xu,name;

 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 Form1->Memo1->Lines->LoadFromFile("_2D.txt");

 c=';';
 for(j=0;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];
  t="";
  count=0;
  for(i=1;i<s.Length()+1;i++)
  {
   if(s[i]!=c)
   {
    t=t+s[i];
   }
   else
   {
    count++;
    if(count==1)
    {
     id=t;
    }
    if(count==2)
    {
     name=t;
    }
    if(count==3)
    {
     xi=t;
    }
    t="";
   }
  }
  xu=t;

  if(id==Form1->StringGrid1->Cells[0][Form1->StringGrid1->Row])
  {
   for(k=xi.ToInt()-1;k<xu.ToInt();k++)
   {
    Form1->StringGrid2->Cells[10][k]=name;
   }
  }

 }

}

void readkinase()
{
 int i,j,k,count;
 char c;
 AnsiString s,t,id,p,aa,name;

 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 Form1->Memo1->Lines->LoadFromFile("_KINASE.txt");

 c=';';
 for(j=0;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];
  t="";
  count=0;
  for(i=1;i<s.Length()+1;i++)
  {
   if(s[i]!=c)
   {
    t=t+s[i];
   }
   else
   {
    count++;
    if(count==1)
    {
     id=t;
    }
    if(count==2)
    {
     p=t;
    }
    if(count==3)
    {
     aa=t;
    }
    t="";
   }
  }
  name=t;

  if(id==Form1->StringGrid1->Cells[0][Form1->StringGrid1->Row])
  {
   k=p.ToInt()-1;
   Form1->StringGrid2->Cells[12][k]=name;
  }

 }

}

void metrics()
{
 int i,j,k,l,p,q,r,count,f,pcount,flag1,flag2,flag3,ptm,gap;
 double d;
 AnsiString s,t,w,aa,ptms;

 cleargrid2();
 Form1->StringGrid2->ColCount=19;
 Form1->StringGrid2->DefaultColWidth=30;
 Form1->StringGrid2->ColWidths[6]=30;

 p=0;
 q=Form1->StringGrid1->Row;
 i=0;

 ptm=0;
 gap=0;
 do
 {

  i++;
  if(Form1->StringGrid1->Cells[i][q]!="-" && Form1->StringGrid1->Cells[i][q]!="")
  {
   p++;
   flag1=0;
   s=Form1->StringGrid1->Cells[i][q];

   ptms="";

   if(s.Length()>1)
   {
    flag1=1;
    ptm++;
    aa=s[1];
    ptms="";
    for(l=3;l<s.Length()+1;l++)
    {
     ptms=ptms+s[l];
    }
   }

   cleargrid3();
   Form1->StringGrid3->ColCount=2;
   count=0;
   flag2=0;
   for(j=0;j<Form1->StringGrid1->RowCount;j++)
   {

    t=Form1->StringGrid1->Cells[i][j];
    if(t[1]==s[1])
    {
     count++;
    }
    else
    {
     if(Form1->Edit3->Text!="0")
     {
      if(ptms=="Phosphorylation" && (t[1]=='S' || t[1]=='T' || t[1]=='Y'))
      {
       count++;
      }
      if(ptms=="O-GalNAc" && (t[1]=='S' || t[1]=='T'))
      {
       count++;
      }
      if(ptms=="Phosphorylation_O-GalNAc" && (t[1]=='S' || t[1]=='T'))
      {
       count++;
      }
      if(ptms=="Methylation" && (t[1]=='E' || t[1]=='R' || t[1]=='K'))
      {
       count++;
      }
     }
    }

    if(t=="-")
    {
     flag2=1;
    }

    w=t[1];
    flag3=0;
    for(k=0;k<Form1->StringGrid3->RowCount;k++)
    {
     if(w==Form1->StringGrid3->Cells[0][k])
     {
      flag3=1;
      r=k;
     }
    }
    if(flag3==0)
    {
     Form1->StringGrid3->Cells[0][Form1->StringGrid3->RowCount-1]=w;
     Form1->StringGrid3->Cells[1][Form1->StringGrid3->RowCount-1]=1;
     Form1->StringGrid3->RowCount++;
    }
    else
    {
     Form1->StringGrid3->Cells[1][r]=Form1->StringGrid3->Cells[1][r].ToInt()+1;
    }
    sortgrid3();

   }

   if(flag2==1)
   {
    gap++;
   }
   pcount=(count*100)/Form1->StringGrid1->RowCount;

   w="";
   f=0;
   for(k=0;k<Form1->StringGrid3->RowCount-1;k++)
   {
    w=w+(Form1->StringGrid3->Cells[0][k]+" "+Form1->StringGrid3->Cells[1][k]+":");
    f=f+Form1->StringGrid3->Cells[1][k].ToInt();
   }
   d=0;
   for(k=0;k<Form1->StringGrid3->RowCount-1;k++)
   {
    t=Form1->StringGrid3->Cells[1][k];
    d=d+((t.ToDouble()/f)*log((t.ToDouble()/f)));
   }
   d=d*-1;

   Form1->StringGrid2->Cells[0][Form1->StringGrid2->RowCount-1]=i;
   Form1->StringGrid2->Cells[1][Form1->StringGrid2->RowCount-1]=p;
   Form1->StringGrid2->Cells[2][Form1->StringGrid2->RowCount-1]=s[1];
   Form1->StringGrid2->Cells[3][Form1->StringGrid2->RowCount-1]=ptms;
   Form1->StringGrid2->Cells[4][Form1->StringGrid2->RowCount-1]=pcount;
   Form1->StringGrid2->Cells[5][Form1->StringGrid2->RowCount-1]=Form1->StringGrid3->RowCount-2;
   Form1->StringGrid2->Cells[6][Form1->StringGrid2->RowCount-1]=w;
   Form1->StringGrid2->Cells[7][Form1->StringGrid2->RowCount-1]=f;
   Form1->StringGrid2->Cells[8][Form1->StringGrid2->RowCount-1]=d;

   Form1->StringGrid2->Cells[9][Form1->StringGrid2->RowCount-1]="";
   Form1->StringGrid2->Cells[10][Form1->StringGrid2->RowCount-1]="";
   Form1->StringGrid2->Cells[11][Form1->StringGrid2->RowCount-1]="";
   Form1->StringGrid2->Cells[12][Form1->StringGrid2->RowCount-1]="";
   Form1->StringGrid2->Cells[13][Form1->StringGrid2->RowCount-1]="";
   Form1->StringGrid2->Cells[14][Form1->StringGrid2->RowCount-1]="";

   Form1->StringGrid2->Cells[15][Form1->StringGrid2->RowCount-1]=0;
   Form1->StringGrid2->Cells[16][Form1->StringGrid2->RowCount-1]=0;

   Form1->StringGrid2->Cells[17][Form1->StringGrid2->RowCount-1]=flag1;
   Form1->StringGrid2->Cells[18][Form1->StringGrid2->RowCount-1]=flag2;

   Form1->StringGrid2->RowCount++;
  }

 }
 while(i<Form1->StringGrid1->ColCount);

 s=Form1->StringGrid2->RowCount-1;
 Form1->StringGrid2->Cells[0][Form1->StringGrid2->RowCount-1]=s;
 Form1->StringGrid2->Cells[4][Form1->StringGrid2->RowCount-1]=1;
 Form1->StringGrid2->Cells[5][Form1->StringGrid2->RowCount-1]=1;
 Form1->StringGrid2->Cells[7][Form1->StringGrid2->RowCount-1]=1;
 s=ptm;
 Form1->StringGrid2->Cells[17][Form1->StringGrid2->RowCount-1]=s;
 s=gap;
 Form1->StringGrid2->Cells[18][Form1->StringGrid2->RowCount-1]=s;
 Form1->StringGrid2->Col=1;
 Form1->StringGrid2->Row=Form1->StringGrid2->RowCount-1;

 readregion(1);
 read2d();
 readregion(2);
 readkinase();

 Form1->Edit3->Text="50";

}

void readmutations()
{
 int i,j,k,count,count2,r,flag,freq;
 double d;
 char c;
 AnsiString s,t,p,w,m,f;

 metrics();
 for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
 {
  Form1->StringGrid2->Cells[5][j]=0;
  Form1->StringGrid2->Cells[6][j]="";
  Form1->StringGrid2->Cells[7][j]=0;
  Form1->StringGrid2->Cells[8][j]=0;
 }

 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 Form1->Memo1->Lines->LoadFromFile("mut"+Form1->Edit1->Text+".txt");

 c=';';
 count2=0;
 for(j=0;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];
  t="";
  count=0;
  for(i=1;i<s.Length()+1;i++)
  {
   if(s[i]!=c)
   {
    t=t+s[i];
   }
   else
   {
    count++;
    if(count==3)
    {
     p=t;
    }
    if(count==4)
    {
     w=t[1];
     m=t[t.Length()];
    }
    if(count==12)
    {
     f=t;
    }
    t="";
   }
  }

  if(w==Form1->StringGrid2->Cells[2][p.ToInt()-1] && m!="X")
  {
   Form1->StringGrid2->Cells[6][p.ToInt()-1]=Form1->StringGrid2->Cells[6][p.ToInt()-1]+m+" "+f+":";
   count2++;
  }

 }

 for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
 {
  s=Form1->StringGrid2->Cells[6][j];
  if(s!="")
  {
   cleargrid3();
   Form1->StringGrid3->ColCount=2;
   t="";
   for(i=1;i<s.Length()+1;i++)
   {
    if(s[i]!=':' && s[i]!=' ')
    {
     t=t+s[i];
    }
    else
    {
     if(s[i]==' ')
     {
      w=t;
     }
     else
     {
      f=t;
      flag=0;
      for(k=0;k<Form1->StringGrid3->RowCount;k++)
      {
       if(w==Form1->StringGrid3->Cells[0][k])
       {
        flag=1;
        r=k;
       }
      }
      if(flag==0)
      {
       Form1->StringGrid3->Cells[0][Form1->StringGrid3->RowCount-1]=w;
       Form1->StringGrid3->Cells[1][Form1->StringGrid3->RowCount-1]=f;
       Form1->StringGrid3->RowCount++;
      }
      else
      {
       Form1->StringGrid3->Cells[1][r]=Form1->StringGrid3->Cells[1][r].ToInt()+f.ToInt();
      }
     }
     t="";
    }
   }
   sortgrid3();
   w="";
   freq=0;
   for(k=0;k<Form1->StringGrid3->RowCount-1;k++)
   {
    w=w+(Form1->StringGrid3->Cells[0][k]+" "+Form1->StringGrid3->Cells[1][k]+":");
    freq=freq+Form1->StringGrid3->Cells[1][k].ToInt();
   }
   d=0;
   for(k=0;k<Form1->StringGrid3->RowCount-1;k++)
   {
    t=Form1->StringGrid3->Cells[1][k];
    d=d+((t.ToDouble()/freq)*log((t.ToDouble()/freq)));
   }
   d=d*-1;

   Form1->StringGrid2->Cells[5][j]=Form1->StringGrid3->RowCount-1;
   Form1->StringGrid2->Cells[6][j]=w;
   Form1->StringGrid2->Cells[7][j]=freq;
   Form1->StringGrid2->Cells[8][j]=d;
  }
 }

 d=0;
 for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
 {
  if(Form1->StringGrid2->Cells[17][j]=="1")
  {
   s=Form1->StringGrid2->Cells[7][j];
   if(s.ToDouble()>d)
   {
    d=s.ToDouble();
   }
  }
 }
 for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
 {
  if(Form1->StringGrid2->Cells[17][j]=="1")
  {
   s=Form1->StringGrid2->Cells[7][j];
   Form1->StringGrid2->Cells[8][j]=s.ToDouble()/d;
  }
 }

 count=0;
 for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
 {
  if(Form1->StringGrid2->Cells[7][j]!="0")
  {
   count++;
  }
 }
 Form1->StringGrid2->Cells[6][Form1->StringGrid2->RowCount-1]=count2;
 Form1->StringGrid2->Cells[7][Form1->StringGrid2->RowCount-1]=0.00075;
 Form1->StringGrid2->Cells[8][Form1->StringGrid2->RowCount-1]=1000;
 Form1->StringGrid2->Cells[1][Form1->StringGrid2->RowCount-1]=count;

}

void cleargraphic()
{
 Form1->Image1->Canvas->Pen->Color=clSilver;
 Form1->Image1->Canvas->Brush->Color=clWhite;
 Form1->Image1->Canvas->Rectangle(0,0,1335,680);
}

void showimage()
{
 Form1->Image1->Visible=true;
 Form1->StringGrid1->Visible=false;
 Form1->StringGrid2->Visible=false;
 Form1->Edit1->Visible=false;
 Form1->Edit2->Visible=false;
 Form1->Edit3->Visible=false;
 Form1->BitBtn1->Visible=false;
 Form1->BitBtn2->Visible=false;
 Form1->BitBtn4->Visible=false;
 Form1->BitBtn5->Visible=false;
 Form1->BitBtn6->Visible=false;
 Form1->BitBtn9->Visible=false;
 Form1->BitBtn11->Visible=false;
 Form1->BitBtn13->Visible=false;
 Form1->BitBtn15->Visible=false;
 Form1->BitBtn16->Visible=false;
}

void hideimage()
{
 Form1->Image1->Visible=false;
 Form1->StringGrid1->Visible=true;
 Form1->StringGrid2->Visible=true;
 Form1->Edit1->Visible=true;
 Form1->Edit2->Visible=true;
 Form1->Edit3->Visible=true;
 Form1->BitBtn1->Visible=true;
 Form1->BitBtn2->Visible=true;
 Form1->BitBtn4->Visible=true;
 Form1->BitBtn5->Visible=true;
 Form1->BitBtn6->Visible=true;
 Form1->BitBtn9->Visible=true;
 Form1->BitBtn11->Visible=true;
 Form1->BitBtn13->Visible=true;
 Form1->BitBtn15->Visible=true;
 Form1->BitBtn16->Visible=true;
}

void setcolors(int i,int j)
{

 if(Form1->StringGrid1->Cells[i][j]=="S+Phosphorylation" || Form1->StringGrid1->Cells[i][j]=="S-Phosphorylation")
 {
  Form1->Image1->Canvas->Pen->Color=clLime;
  Form1->Image1->Canvas->Brush->Color=clLime;
 }
 if(Form1->StringGrid1->Cells[i][j]=="T+Phosphorylation" || Form1->StringGrid1->Cells[i][j]=="T-Phosphorylation")
 {
  Form1->Image1->Canvas->Pen->Color=clLime;
  Form1->Image1->Canvas->Brush->Color=clLime;
 }
 if(Form1->StringGrid1->Cells[i][j]=="Y+Phosphorylation" || Form1->StringGrid1->Cells[i][j]=="Y-Phosphorylation")
 {
  Form1->Image1->Canvas->Pen->Color=clLime;
  Form1->Image1->Canvas->Brush->Color=clLime;
 }
 if(Form1->StringGrid1->Cells[i][j]=="D+Phosphorylation" || Form1->StringGrid1->Cells[i][j]=="D-Phosphorylation")
 {
  Form1->Image1->Canvas->Pen->Color=clLime;
  Form1->Image1->Canvas->Brush->Color=clLime;
 }
 if(Form1->StringGrid1->Cells[i][j]=="E+Phosphorylation" || Form1->StringGrid1->Cells[i][j]=="E-Phosphorylation")
 {
  Form1->Image1->Canvas->Pen->Color=clLime;
  Form1->Image1->Canvas->Brush->Color=clLime;
 }
 if(Form1->StringGrid1->Cells[i][j]=="N+Glycosylation" || Form1->StringGrid1->Cells[i][j]=="N-Glycosylation")
 {
  Form1->Image1->Canvas->Pen->Color=clBlue;
  Form1->Image1->Canvas->Brush->Color=clBlue;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="S+O-GalNAc" || Form1->StringGrid1->Cells[i][j]=="S-O-GalNAc")
 {
  Form1->Image1->Canvas->Pen->Color=clTeal;
  Form1->Image1->Canvas->Brush->Color=clTeal;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="T+O-GalNAc" || Form1->StringGrid1->Cells[i][j]=="T-O-GalNAc")
 {
  Form1->Image1->Canvas->Pen->Color=clTeal;
  Form1->Image1->Canvas->Brush->Color=clTeal;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="K+Sumoylation" || Form1->StringGrid1->Cells[i][j]=="K-Sumoylation")
 {
  Form1->Image1->Canvas->Pen->Color=clYellow;
  Form1->Image1->Canvas->Brush->Color=clYellow;
 }
 if(Form1->StringGrid1->Cells[i][j]=="K+Ubiquitination" || Form1->StringGrid1->Cells[i][j]=="K-Ubiquitination")
 {
  Form1->Image1->Canvas->Pen->Color=RGB(204,204,0);
  Form1->Image1->Canvas->Brush->Color=RGB(204,204,0);
 }
 if(Form1->StringGrid1->Cells[i][j]=="C+Palmitoylation" || Form1->StringGrid1->Cells[i][j]=="C-Palmitoylation")
 {
  //Form1->Image1->Canvas->Pen->Color=RGB(153,153,0);
  //Form1->Image1->Canvas->Brush->Color=RGB(153,153,0);
  Form1->Image1->Canvas->Pen->Color=clOlive;
  Form1->Image1->Canvas->Brush->Color=clOlive;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="C+Disulfide bond" || Form1->StringGrid1->Cells[i][j]=="C-Disulfide bond")
 {
  Form1->Image1->Canvas->Pen->Color=RGB(110,110,110);
  Form1->Image1->Canvas->Brush->Color=RGB(110,110,110);
 }
 if(Form1->StringGrid1->Cells[i][j]=="D+Cleavage" || Form1->StringGrid1->Cells[i][j]=="D-Cleavage")
 {
  Form1->Image1->Canvas->Pen->Color=RGB(55,55,55);
  Form1->Image1->Canvas->Brush->Color=RGB(55,55,55);
 }
 if(Form1->StringGrid1->Cells[i][j]=="R+Methylation" || Form1->StringGrid1->Cells[i][j]=="R-Methylation")
 {
  Form1->Image1->Canvas->Pen->Color=clPurple;
  Form1->Image1->Canvas->Brush->Color=clPurple;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="E+Methylation" || Form1->StringGrid1->Cells[i][j]=="E-Methylation")
 {
  Form1->Image1->Canvas->Pen->Color=clPurple;
  Form1->Image1->Canvas->Brush->Color=clPurple;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="K+Methylation" || Form1->StringGrid1->Cells[i][j]=="K-Methylation")
 {
  Form1->Image1->Canvas->Pen->Color=clPurple;
  Form1->Image1->Canvas->Brush->Color=clPurple;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="S+Phosphorylation_O-GalNAc" || Form1->StringGrid1->Cells[i][j]=="S-Phosphorylation_O-GalNAc")
 {
  Form1->Image1->Canvas->Pen->Color=clGreen;
  Form1->Image1->Canvas->Brush->Color=clGreen;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }
 if(Form1->StringGrid1->Cells[i][j]=="T+Phosphorylation_O-GalNAc" || Form1->StringGrid1->Cells[i][j]=="T-Phosphorylation_O-GalNAc")
 {
  Form1->Image1->Canvas->Pen->Color=clGreen;
  Form1->Image1->Canvas->Brush->Color=clGreen;
  //Form1->Image1->Canvas->Font->Color=clWhite;
 }

}

void display2()
{
 int i,j,flag,x,y,d,p,q,dy;
 AnsiString s,t;

 cleargraphic();

 p=Form1->Edit2->Text.ToInt();
 q=Form1->Edit3->Text.ToInt();

 Form1->Image1->Canvas->Font->Color=clBlack;

 //dy=50;
 dy=20;

 y=30+dy;

 Form1->Image1->Canvas->TextOut(10,10+dy,"Species");
 for(j=q;j<Form1->StringGrid1->RowCount;j++)
 {
  Form1->Image1->Canvas->TextOut(10,y+1,Form1->StringGrid1->Cells[0][j]);
  y=y+14;
 }

 x=Form1->Edit1->Text.ToInt();
 for(i=p;i<p+80;i++)
 {

  Form1->Image1->Canvas->Pen->Color=clWhite;
  Form1->Image1->Canvas->Brush->Color=clWhite;
  Form1->Image1->Canvas->Font->Color=clBlack;
  if(i%5==0 && Form1->StringGrid1->Cells[i][0]!="")
  {
   Form1->Image1->Canvas->TextOut(x,10+dy,i);
  }

  flag=0;
  s=Form1->StringGrid1->Cells[i][0];
  for(j=1;j<Form1->StringGrid1->RowCount;j++)
  {
   if(Form1->StringGrid1->Cells[i][j]!=s)
   {
    flag=1;
   }
  }

  if(Form1->StringGrid1->Cells[i][0]!="")
  {
   y=30+dy;

   for(j=q;j<Form1->StringGrid1->RowCount;j++)
   {

    t=Form1->StringGrid1->Cells[i][j];

    if(flag==0)
    {
     Form1->Image1->Canvas->Font->Color=clRed;
    }
    else
    {
     Form1->Image1->Canvas->Font->Color=clBlack;
     if(t.Length()>1 && t[2]=='+')
     {
      Form1->Image1->Canvas->Font->Color=clWhite;
     }
    }

    Form1->Image1->Canvas->Pen->Color=clWhite;
    Form1->Image1->Canvas->Brush->Color=clWhite;
    if(j==Form1->StringGrid1->Row)
    {
     Form1->Image1->Canvas->Pen->Color=clSilver;
     Form1->Image1->Canvas->Brush->Color=clSilver;
    }

    setcolors(i,j);
    Form1->Image1->Canvas->Rectangle(x,y,x+15,y+15);
    Form1->Image1->Canvas->TextOut(x+2,y+1,Form1->StringGrid1->Cells[i][j][1]);

    y=y+14;
   }

   x=x+14;
  }

 }

}

void histogram()
{
 int i,j,inc,count,flag,n;
 double x,y,f,p;
 AnsiString s,t;

 cleargraphic();

 f=Form1->StringGrid2->Cells[Form1->StringGrid2->Col][Form1->StringGrid2->RowCount-1].ToDouble();

 x=120;
 y=250;
 inc=Form1->Edit2->Text.ToInt();
 count=0;

 for(j=Form1->Edit1->Text.ToInt();j<Form1->StringGrid2->RowCount-1;j++)
 {
  if(Form1->StringGrid2->Cells[17][j]=="1" &&
  //Form1->StringGrid2->Cells[8][j].ToDouble()<=0.06
  Form1->StringGrid2->Cells[18][j]=="0"
  //&& !(Form1->StringGrid2->Cells[18][j]=="0" && Form1->StringGrid2->Cells[4][j].ToDouble()>50)
  )
  {
   count++;

   p=Form1->StringGrid2->Cells[Form1->StringGrid2->Col][j].ToDouble();

   Form1->Image1->Canvas->Brush->Color=clSilver;
   Form1->Image1->Canvas->Pen->Color=clSilver;
   setcolors(Form1->StringGrid2->Cells[0][j].ToInt(),Form1->StringGrid1->Row);
   Form1->Image1->Canvas->Rectangle(x,y,x+20,y-(p*f));

   Form1->Image1->Canvas->Brush->Color=clWhite;
   Form1->Image1->Canvas->Font->Color=clBlack;
   if(Form1->StringGrid2->Col==4)
   {
    Form1->Image1->Canvas->TextOut(10,y-20,"Conservation");
   }
   if(Form1->StringGrid2->Col==5)
   {
    Form1->Image1->Canvas->TextOut(10,y-20,"Mutations");
   }
   if(Form1->StringGrid2->Col==8)
   {
    Form1->Image1->Canvas->TextOut(10,y-20,"Mutation Frequency");
   }

   Form1->Image1->Canvas->TextOut(10,y+20,"Residue");

   Form1->Image1->Canvas->TextOut(10,y+50,"SARS-CoV-2 site");
   Form1->Image1->Canvas->TextOut(10,y+80,"Domain");
   Form1->Image1->Canvas->TextOut(10,y+110,"Kinase prediction");


   Form1->Image1->Canvas->TextOut(x,y+20,Form1->StringGrid2->Cells[2][j]);
   Form1->Image1->Canvas->TextOut(x,y+50,Form1->StringGrid2->Cells[1][j]);
   Form1->Image1->Canvas->TextOut(x,y+80,Form1->StringGrid2->Cells[9][j]);
   Form1->Image1->Canvas->TextOut(x+Form1->StringGrid2->Cells[15][j].ToInt(),y+110,Form1->StringGrid2->Cells[12][j]);


   Form1->Image1->Canvas->Font->Color=clBlack;
   if(Form1->StringGrid2->Col==4 && p>Form1->Edit3->Text.ToInt())
   {
    Form1->Image1->Canvas->Font->Color=clRed;
   }
   if(Form1->StringGrid2->Col==8 && p<=0.06)
   {
    Form1->Image1->Canvas->Font->Color=clRed;
   }


   if(Form1->StringGrid2->Col==4)
   {
    Form1->Image1->Canvas->TextOut(x,y-(p*f)-20,Form1->StringGrid2->Cells[4][j]+" %");
   }
   else
   {
    s=Form1->StringGrid2->Cells[Form1->StringGrid2->Col][j];
    t="";
    for(n=1;n<s.Length()+1;n++)
    {
     if(n<7)
     {
      t=t+s[n];
     }
    }
    Form1->Image1->Canvas->TextOut(x,y-(p*f)-20,t);
   }

   s=Form1->StringGrid2->Cells[6][j];
   flag=0;
   for(i=1;i<s.Length()+1;i++)
   {
    if(s[i]=='-')
    {
     flag=1;
    }
   }
   if(flag==1)
   {
    Form1->Image1->Canvas->TextOut(x,y-(p*f)-40," _");
   }

   x=x+inc;

  }
 }

 Form1->Image1->Canvas->Font->Color=clBlack;
 s=count;
 Form1->Image1->Canvas->TextOut(10,10,s);

}

void sequence1()
{
 int i,j,x,y,count1,count2;
 AnsiString s,t;

 cleargraphic();

 x=10;
 y=80;

 j=Form1->StringGrid1->Row;

 count1=0;
 count2=0;
 for(i=1;i<Form1->StringGrid1->ColCount;i++)
 {
  s=Form1->StringGrid1->Cells[i][j];

  Form1->Image1->Canvas->Pen->Color=clWhite;
  Form1->Image1->Canvas->Brush->Color=clWhite;
  Form1->Image1->Canvas->Font->Color=clBlack;

  if(s!="" && s!="-")
  {

   count1++;

   if(s.Length()>1)
   {
    count2++;
    setcolors(i,j);
   }
   Form1->Image1->Canvas->Pen->Color=clWhite;
   Form1->Image1->Canvas->Rectangle(x,y,x+13,y+15);
   Form1->Image1->Canvas->TextOut(x+1,y+1,s[1]);
   Form1->Image1->Canvas->Brush->Color=clWhite;
   Form1->Image1->Canvas->Font->Color=clBlack;
   if(count1%10==0 && count1!=120 && count1!=330 && count1!=1160)
   {
    t=count1;
    Form1->Image1->Canvas->TextOut(x+1,y-14,t);
   }

   Form1->Image1->Canvas->Font->Color=clRed;


   Form1->Image1->Canvas->Font->Color=clBlack;

   x=x+12;

   if(count1%80==0)
   {
    x=10;
    y=y+28;
   }

  }

 }

 s=count1;
 Form1->Image1->Canvas->TextOut(20,y+50,"Residues = "+s);
 s=count2;
 Form1->Image1->Canvas->TextOut(200,y+50,"PTM sites = "+s);

}

void setgrid2()
{
 int j;
 AnsiString s;
 s=Form1->StringGrid2->Cells[Form1->StringGrid2->Col][Form1->StringGrid2->Row];
 for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
 {
  if(Form1->StringGrid2->Col==9)
  {
   if(Form1->StringGrid2->Cells[9][j]==s)
   {
    Form1->StringGrid2->Cells[9][j]="";
   }
  }
  if(Form1->StringGrid2->Col==10)
  {
   if(Form1->StringGrid2->Cells[10][j]==s)
   {
    Form1->StringGrid2->Cells[10][j]="";
   }
  }
  if(Form1->StringGrid2->Col==15)
  {
   Form1->StringGrid2->Cells[15][j]=0;
  }
  if(Form1->StringGrid2->Col==16)
  {
   Form1->StringGrid2->Cells[16][j]=0;
  }
  if(Form1->StringGrid2->Col==17)
  {
   Form1->StringGrid2->Cells[17][j]=1;
  }
  if(Form1->StringGrid2->Col==18)
  {
   Form1->StringGrid2->Cells[18][j]=0;
  }
 }

 if(Form1->StringGrid2->Col==0)
 {
  Form1->StringGrid1->Col=s.ToInt();
 }

}

void outdata()
{
 int i,j;
 AnsiString s1,s2;

 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();

 Form1->Memo1->Lines->Add("AlignP;Site;AA;PTM;Conservation;Mutations;Muts;MutationFreq;Entropy;Domain;2D;IDR;Kinase;X;Y;P1;P2;Ptm;Gap");

 for(j=0;j<Form1->StringGrid2->RowCount-1;j++)
 {
  s1="";
  for(i=0;i<Form1->StringGrid2->ColCount;i++)
  {
   s1=s1+Form1->StringGrid2->Cells[i][j]+";";
  }
  s2="";
  for(i=1;i<s1.Length();i++)
  {
   s2=s2+s1[i];
  }
  Form1->Memo1->Lines->Add(s2);
 }

 Form1->Memo1->Lines->SaveToFile("GRID.txt");

}



//---------------------------------------------------



void __fastcall TForm1::FormCreate(TObject *Sender)
{
 cleargraphic();
 hideimage();
 Form1->Edit1->Text="N";
 Form1->Edit2->Text="corona";
}

void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
 readalign();
}

void __fastcall TForm1::BitBtn2Click(TObject *Sender)
{
 readptms();
 mapping();
 propagate();
 Form1->Edit1->Text=120;
 Form1->Edit2->Text=1;
 Form1->Edit3->Text=0;
}

void __fastcall TForm1::BitBtn4Click(TObject *Sender)
{
 showimage();
 display2();
 Form1->Edit2->Text=Form1->Edit2->Text.ToInt()+10;
 Form1->BitBtn4->Visible=true;
 Form1->BitBtn15->Visible=true;
}

void __fastcall TForm1::BitBtn15Click(TObject *Sender)
{
 showimage();
 display2();
 Form1->Edit3->Text=Form1->Edit3->Text.ToInt()+1;
 Form1->BitBtn4->Visible=true;
 Form1->BitBtn15->Visible=true;
}

void __fastcall TForm1::BitBtn5Click(TObject *Sender)
{
 metrics();
 Form1->Edit1->Text=0;
 Form1->Edit2->Text=40;
}

void __fastcall TForm1::BitBtn6Click(TObject *Sender)
{
 showimage();
 histogram();
}

void __fastcall TForm1::BitBtn9Click(TObject *Sender)
{
 showimage();
 sequence1();
}

void __fastcall TForm1::BitBtn11Click(TObject *Sender)
{
 readmutations();
 Form1->Edit1->Text=0;
 Form1->Edit2->Text=50;
}

void __fastcall TForm1::BitBtn16Click(TObject *Sender)
{
 setgrid2();
}

void __fastcall TForm1::BitBtn13Click(TObject *Sender)
{
 outdata();
}

void __fastcall TForm1::Image1MouseDown(TObject *Sender,TMouseButton Button,TShiftState Shift,int X,int Y)
{
 if(X-10<0)
 {
  Form1->Edit2->Text=0;
 }
 else
 {
  if(Y<100)
  {
   Form1->Edit2->Text=X-10+1;
  }
  else
  {
   Form1->Edit2->Text=X-10+1001;
  }
 }
}

void __fastcall TForm1::Image1DblClick(TObject *Sender)
{
 hideimage();
}

void __fastcall TForm1::FormClick(TObject *Sender)
{
 hideimage();
 cleargraphic();
}

void __fastcall TForm1::FormDblClick(TObject *Sender)
{
 hideimage();
 cleargraphic();
 Form1->Edit1->Text="N";
 Form1->Edit2->Text="corona";
 Form1->Edit3->Text=0;
}

void __fastcall TForm1::StringGrid3DblClick(TObject *Sender)
{
 Form1->StringGrid3->Visible=false;
}






