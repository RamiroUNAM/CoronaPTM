#include <vcl.h>
#pragma hdrstop
#include "SeqUnit1.h"
#pragma package(smart_init)
#pragma resource "*.dfm"
#include "math.h"
#include "fstream.h"


TForm1 *Form1;


__fastcall TForm1::TForm1(TComponent* Owner):TForm(Owner)
{
}

void cleargrid1()
{
 int i,j;
 for(j=0;j<Form1->StringGrid1->RowCount;j++)
 {
  for(i=0;i<Form1->StringGrid1->ColCount;i++)
  {
   Form1->StringGrid1->Cells[i][j]="";
  }
 }
 Form1->StringGrid1->ColCount=1;
 Form1->StringGrid1->RowCount=1;
 Form1->StringGrid1->Row=0;
 Form1->StringGrid1->DefaultColWidth=120;
 Form1->StringGrid1->DefaultRowHeight=15;
}

void cleargrid2()
{
 int i,j;
 for(j=0;j<Form1->StringGrid2->RowCount;j++)
 {
  for(i=0;i<Form1->StringGrid2->ColCount;i++)
  {
   Form1->StringGrid2->Cells[i][j]="";
  }
 }
 Form1->StringGrid2->ColCount=2;
 Form1->StringGrid2->RowCount=1;
 Form1->StringGrid2->Row=0;
 Form1->StringGrid2->DefaultColWidth=120;
 Form1->StringGrid2->DefaultRowHeight=15;
}

void cleargrid3()
{
 int i,j;
 for(j=0;j<Form1->StringGrid3->RowCount;j++)
 {
  for(i=0;i<Form1->StringGrid3->ColCount;i++)
  {
   Form1->StringGrid3->Cells[i][j]="";
  }
 }
 Form1->StringGrid3->ColCount=4;
 Form1->StringGrid3->RowCount=1;
 Form1->StringGrid3->Row=0;
 Form1->StringGrid3->DefaultColWidth=120;
 Form1->StringGrid3->DefaultRowHeight=15;
}

void sortgrid3(int d)
{
 int i,j;
 AnsiString s1,s2,s3,s4;
 for(i=0;i<Form1->StringGrid3->RowCount-1;i++)
 {
  for(j=0;j<Form1->StringGrid3->RowCount-1;j++)
  {
   if(d==1)
   {
    if(Form1->StringGrid3->Cells[2][j].ToDouble()<Form1->StringGrid3->Cells[2][i].ToDouble())
    {
     s1=Form1->StringGrid3->Cells[0][i];
     s2=Form1->StringGrid3->Cells[1][i];
     s3=Form1->StringGrid3->Cells[2][i];
     s4=Form1->StringGrid3->Cells[3][i];
     Form1->StringGrid3->Cells[0][i]=Form1->StringGrid3->Cells[0][j];
     Form1->StringGrid3->Cells[1][i]=Form1->StringGrid3->Cells[1][j];
     Form1->StringGrid3->Cells[2][i]=Form1->StringGrid3->Cells[2][j];
     Form1->StringGrid3->Cells[3][i]=Form1->StringGrid3->Cells[3][j];
     Form1->StringGrid3->Cells[0][j]=s1;
     Form1->StringGrid3->Cells[1][j]=s2;
     Form1->StringGrid3->Cells[2][j]=s3;
     Form1->StringGrid3->Cells[3][j]=s4;
    }
   }
   if(d==2)
   {
    if(Form1->StringGrid3->Cells[2][j].ToDouble()>Form1->StringGrid3->Cells[2][i].ToDouble())
    {
     s1=Form1->StringGrid3->Cells[0][i];
     s2=Form1->StringGrid3->Cells[1][i];
     s3=Form1->StringGrid3->Cells[2][i];
     s4=Form1->StringGrid3->Cells[3][i];
     Form1->StringGrid3->Cells[0][i]=Form1->StringGrid3->Cells[0][j];
     Form1->StringGrid3->Cells[1][i]=Form1->StringGrid3->Cells[1][j];
     Form1->StringGrid3->Cells[2][i]=Form1->StringGrid3->Cells[2][j];
     Form1->StringGrid3->Cells[3][i]=Form1->StringGrid3->Cells[3][j];
     Form1->StringGrid3->Cells[0][j]=s1;
     Form1->StringGrid3->Cells[1][j]=s2;
     Form1->StringGrid3->Cells[2][j]=s3;
     Form1->StringGrid3->Cells[3][j]=s4;
    }
   }
  }
 }
}

void showimage()
{
 Form1->StringGrid1->Visible=false;
 Form1->StringGrid2->Visible=false;
 Form1->StringGrid3->Visible=false;
 Form1->BitBtn17->Visible=false;
 Form1->BitBtn18->Visible=false;
 Form1->Image1->Visible=true;
}

void hideimage()
{
 Form1->Image1->Visible=false;
 Form1->StringGrid1->Visible=true;
 Form1->StringGrid2->Visible=true;
 Form1->StringGrid3->Visible=true;
 Form1->BitBtn17->Visible=true;
 Form1->BitBtn18->Visible=true;
}

void cleargraphic()
{
 Form1->Image1->Width=1165;
 Form1->Image1->Height=595;
 Form1->Image1->Top=10;
 Form1->Image1->Left=10;
 Form1->Image1->Canvas->Pen->Color=clBlack;
 Form1->Image1->Canvas->Brush->Color=clWhite;
 Form1->Image1->Canvas->Rectangle(0,0,1165,595);
}

void readdata()
{
 int i,j,k;
 char c;
 AnsiString s,t;
 cleargrid1();
 cleargrid2();
 cleargrid3();
 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 Form1->Memo1->Lines->LoadFromFile(Form1->Edit1->Text+".txt");
 c=';';
 s=Form1->Memo1->Lines->Strings[0];
 for(i=1;i<s.Length()+1;i++)
 {
  if(s[i]==c)
  {
   Form1->StringGrid1->ColCount++;
  }
 }
 for(j=0;j<Form1->Memo1->Lines->Count;j++)
 {
  s=Form1->Memo1->Lines->Strings[j];
  t="";
  k=0;
  for(i=1;i<s.Length()+1;i++)
  {
   if(s[i]!=c)
   {
    t=t+s[i];
   }
   else
   {
    Form1->StringGrid1->Cells[k][Form1->StringGrid1->RowCount-1]=t;
    k++;
    t="";
   }
  }
  Form1->StringGrid1->Cells[k][Form1->StringGrid1->RowCount-1]=t;
  Form1->StringGrid1->RowCount++;
  if(Form1->StringGrid1->RowCount%1000==0)
  {
   Form1->Edit2->Text=Form1->StringGrid1->RowCount;
   Form1->Edit2->Repaint();
  }
 }
 s=Form1->StringGrid1->RowCount-2;
 Form1->StringGrid1->Cells[0][Form1->StringGrid1->RowCount-1]=s;
 Form1->StringGrid1->Col=1;
 Form1->StringGrid1->Row=Form1->StringGrid1->RowCount-1;
}

void setcolors()
{
 Form1->Image1->Canvas->Pen->Color=clRed;
 Form1->Image1->Canvas->Brush->Color=clRed;

 if(Form1->StringGrid1->Cells[2][Form1->StringGrid1->Row]=="Phosphorylation")
 {
  Form1->Image1->Canvas->Pen->Color=clLime;
  Form1->Image1->Canvas->Brush->Color=clLime;
 }
 if(Form1->StringGrid1->Cells[2][Form1->StringGrid1->Row]=="Glycosylation")
 {
  Form1->Image1->Canvas->Pen->Color=clBlue;
  Form1->Image1->Canvas->Brush->Color=clBlue;
 }
 if(Form1->StringGrid1->Cells[2][Form1->StringGrid1->Row]=="O-GalNAc")
 {
  Form1->Image1->Canvas->Pen->Color=clTeal;
  Form1->Image1->Canvas->Brush->Color=clTeal;
 }
 if(Form1->StringGrid1->Cells[2][Form1->StringGrid1->Row]=="Sumoylation")
 {
  Form1->Image1->Canvas->Pen->Color=clYellow;
  Form1->Image1->Canvas->Brush->Color=clYellow;
 }
 if(Form1->StringGrid1->Cells[2][Form1->StringGrid1->Row]=="Palmitoylation")
 {
  Form1->Image1->Canvas->Pen->Color=clOlive;
  Form1->Image1->Canvas->Brush->Color=clOlive;
 }
 if(Form1->StringGrid1->Cells[2][Form1->StringGrid1->Row]=="Methylation")
 {
  Form1->Image1->Canvas->Pen->Color=clPurple;
  Form1->Image1->Canvas->Brush->Color=clPurple;
 }
 if(Form1->StringGrid1->Cells[2][Form1->StringGrid1->Row]=="Phosphorylation_O-GalNAc")
 {
  Form1->Image1->Canvas->Pen->Color=clGreen;
  Form1->Image1->Canvas->Brush->Color=clGreen;
 }

}

void drawfuzzysets(int n)
{
 int i,j,r;
 double xc,yc,fx,fy,xi,xu,mid,xf,yf,p;
 AnsiString s;

 fx=Form1->Edit2->Text.ToDouble();
 fy=Form1->Edit3->Text.ToDouble();

 xc=Form1->StringGrid2->Cells[1][1].ToDouble()*fx;
 if(xc>0)
 {
  xc=(xc*-1)+200;
 }
 else
 {
  xc=200;
 }
 yc=250;

 for(j=1;j<Form1->StringGrid2->RowCount-1;j++)
 {
  if(Form1->StringGrid2->Cells[1][j]!="" && Form1->StringGrid2->Cells[2][j]!="")
  {
   xi=Form1->StringGrid2->Cells[1][j].ToDouble();
   xu=Form1->StringGrid2->Cells[2][j].ToDouble();
   mid=xc+((((xu-xi)/2)+xi)*fx);

   if(n==0)
   {
    if(j==1)
    {
     Form1->Image1->Canvas->Pen->Color=clGray;
     Form1->Image1->Canvas->MoveTo(mid,yc-(1*fy));
     Form1->Image1->Canvas->LineTo(mid,yc);
     Form1->Image1->Canvas->MoveTo(mid-30,yc);
     Form1->Image1->Canvas->LineTo(xc+(xu*fx),yc);
     Form1->Image1->Canvas->Pen->Color=clBlack;
     Form1->Image1->Canvas->MoveTo(mid-20,yc-(1*fy));
     Form1->Image1->Canvas->LineTo(mid,yc-(1*fy));
     Form1->Image1->Canvas->MoveTo(mid,yc-(1*fy));
     Form1->Image1->Canvas->LineTo(xc+(xu*fx),yc);
     s=((xu-xi)/2)+xi;
     Form1->Image1->Canvas->TextOut(mid,yc+15,s);
     Form1->Image1->Canvas->TextOut(mid-45,yc-5,0);
     Form1->Image1->Canvas->TextOut(mid-45,yc-(1*fy)-5,1);
     Form1->Image1->Canvas->TextOut(mid-160,yc-(0.5*fy)-5,"Degree of membership");

     p=mid-45;
     s=Form1->StringGrid1->RowCount-2;
     Form1->Image1->Canvas->TextOut(p,yc-(1*fy)-80,"PTM sites = "+s);

     p=p-120;

    }
    else
    {
     if(j==Form1->StringGrid2->RowCount-2)
     {
      Form1->Image1->Canvas->Pen->Color=clGray;
      Form1->Image1->Canvas->MoveTo(mid,yc-(1*fy));
      Form1->Image1->Canvas->LineTo(mid,yc);
      Form1->Image1->Canvas->MoveTo(xc+(xi*fx),yc);
      Form1->Image1->Canvas->LineTo(mid+30,yc);
      Form1->Image1->Canvas->Pen->Color=clBlack;
      Form1->Image1->Canvas->MoveTo(xc+(xi*fx),yc);
      Form1->Image1->Canvas->LineTo(mid,yc-(1*fy));
      Form1->Image1->Canvas->MoveTo(mid,yc-(1*fy));
      Form1->Image1->Canvas->LineTo(mid+20,yc-(1*fy));
      s=((xu-xi)/2)+xi;
      Form1->Image1->Canvas->TextOut(mid,yc+15,s);

      Form1->Image1->Canvas->Pen->Color=clBlack;
      Form1->Image1->Canvas->MoveTo(mid+60,0);
      Form1->Image1->Canvas->LineTo(mid+60,600);
     }
     else
     {
      Form1->Image1->Canvas->Pen->Color=clGray;
      Form1->Image1->Canvas->MoveTo(xc+(xi*fx),yc);
      Form1->Image1->Canvas->LineTo(mid,yc);
      Form1->Image1->Canvas->Pen->Color=clBlack;
      Form1->Image1->Canvas->MoveTo(xc+(xi*fx),yc);
      Form1->Image1->Canvas->LineTo(mid,yc-(1*fy));
      Form1->Image1->Canvas->MoveTo(mid,yc-(1*fy));
      Form1->Image1->Canvas->LineTo(xc+(xu*fx),yc);
     }
    }
    s=Form1->StringGrid2->Cells[0][j];
    Form1->Image1->Canvas->TextOut(mid,yc-(1*fy)-30,s);
    Form1->Image1->Canvas->Pen->Color=clBlack;

    if(s=="Mid")
    {
     Form1->Image1->Canvas->TextOut(mid-40,yc+35,Form1->StringGrid1->Cells[Form1->StringGrid1->Col][0]);
    }
   }

  }
 }

 xf=Form1->StringGrid1->Cells[Form1->StringGrid1->Col][Form1->StringGrid1->Row].ToDouble();
 yf=Form1->StringGrid2->Cells[3][Form1->StringGrid2->RowCount-1].ToDouble();

 setcolors();

 r=4;
 Form1->Image1->Canvas->Ellipse((xc+(xf*fx))-r,(yc-(yf*fy))-r,(xc+(xf*fx))+r,(yc-(yf*fy))+r);
 Form1->Image1->Canvas->Brush->Color=clWhite;

 if(n==1)
 {
  Form1->Image1->Canvas->MoveTo(xc+(xf*fx),yc-(yf*fy));
  Form1->Image1->Canvas->LineTo(xc+(xf*fx),yc+30);
  Form1->Image1->Canvas->Font->Color=clBlack;
  Form1->Image1->Canvas->TextOut(xc+(xf*fx),yc+50,xf);
  Form1->Image1->Canvas->TextOut(xc+(xf*fx),yc+70,Form1->StringGrid2->Cells[2][Form1->StringGrid2->RowCount-1]);
  Form1->Image1->Canvas->TextOut(xc+(xf*fx),yc+90,yf);
  Form1->Image1->Canvas->Font->Color=clBlack;
 }


}

void limits()
{
 int j;
 double min,max,d;
 min=Form1->StringGrid1->Cells[Form1->StringGrid1->Col][1].ToDouble();
 max=min;
 for(j=1;j<Form1->StringGrid1->RowCount-1;j++)
 {
  d=Form1->StringGrid1->Cells[Form1->StringGrid1->Col][j].ToDouble();
  if(d<min)
  {
   min=d;
  }
  if(d>max)
  {
   max=d;
  }
 }
 Form1->Edit2->Text=min;
 Form1->Edit3->Text=max;
}

void fuzzysets()
{
 int j,n;
 double min,max,h,xi,xu,count;

 cleargrid2();
 n=Form1->Edit1->Text.ToInt();
 Form1->StringGrid2->ColCount=4;
 Form1->StringGrid2->RowCount=n+2;
 Form1->StringGrid2->Cells[0][0]="Fuzzy Sets";
 if(n==3)
 {
  Form1->StringGrid2->Cells[0][1]="Low";
  Form1->StringGrid2->Cells[0][2]="Mid";
  Form1->StringGrid2->Cells[0][3]="High";
 }
 else
 {
  if(n==5)
  {
   Form1->StringGrid2->Cells[0][1]="Very Low";
   Form1->StringGrid2->Cells[0][2]="Low";
   Form1->StringGrid2->Cells[0][3]="Mid";
   Form1->StringGrid2->Cells[0][4]="High";
   Form1->StringGrid2->Cells[0][5]="Very High";
  }
  else
  {
   for(j=1;j<Form1->StringGrid2->RowCount-1;j++)
   {
    Form1->StringGrid2->Cells[0][j]=j;
   }
  }
 }

 limits();

 min=Form1->Edit2->Text.ToDouble();
 max=Form1->Edit3->Text.ToDouble();
 count=0;
 for(j=1;j<Form1->StringGrid2->RowCount;j++)
 {
  if(Form1->StringGrid2->Cells[0][j]!="")
  {
   count++;
  }
 }
 h=(max-min)/(count-1);
 xi=min-h;
 xu=min+h;
 for(j=1;j<count+1;j++)
 {
  Form1->StringGrid2->Cells[1][j]=xi;
  Form1->StringGrid2->Cells[2][j]=xu;
  xi=xi+h;
  xu=xu+h;
 }

 Form1->Edit2->Text=50;
 Form1->Edit3->Text=100;

}

void fuzzy(int n)
{
 int i,j;
 double xi,xu,xp,d,max;
 xp=Form1->StringGrid1->Cells[Form1->StringGrid1->Col][Form1->StringGrid1->Row].ToDouble();
 for(j=1;j<Form1->StringGrid2->RowCount;j++)
 {
  if(Form1->StringGrid2->Cells[1][j]!="" && Form1->StringGrid2->Cells[2][j]!="")
  {
   xi=Form1->StringGrid2->Cells[1][j].ToDouble();
   xu=Form1->StringGrid2->Cells[2][j].ToDouble();
   if(xp>=xi && xp<=xu)
   {
    if(xp>(((xu-xi)/2)+xi))
    {
     Form1->StringGrid2->Cells[3][j]=(xu-xp)/((xu-xi)/2);
    }
    else
    {
     if(xp<(((xu-xi)/2)+xi))
     {
      Form1->StringGrid2->Cells[3][j]=(xp-xi)/((xu-xi)/2);
     }
     else
     {
      Form1->StringGrid2->Cells[3][j]=1;
     }
    }
   }
   else
   {
    Form1->StringGrid2->Cells[3][j]=0;
   }
  }
 }
 max=0;
 for(j=1;j<Form1->StringGrid2->RowCount-1;j++)
 {
  d=Form1->StringGrid2->Cells[3][j].ToDouble();
  if(d>max)
  {
   max=d;
   i=j;
  }
 }
 Form1->StringGrid2->Cells[2][Form1->StringGrid2->RowCount-1]=Form1->StringGrid2->Cells[0][i];
 Form1->StringGrid2->Cells[3][Form1->StringGrid2->RowCount-1]=Form1->StringGrid2->Cells[3][i];

 drawfuzzysets(n);

 if(n==2)
 {
  Form1->StringGrid1->Cells[Form1->StringGrid1->Col][Form1->StringGrid1->Row]=Form1->StringGrid2->Cells[0][i];
 }

}

void outdata(int n)
{
 int i,j;
 AnsiString s1,s2;
 Form1->Memo1->Width=100000;
 Form1->Memo1->Lines->Clear();
 for(j=0;j<Form1->StringGrid1->RowCount-1;j++)
 {
  s1="";
  for(i=0;i<Form1->StringGrid1->ColCount;i++)
  {
   if(Form1->StringGrid1->Cells[i][Form1->StringGrid1->RowCount-1]=="+")
   {
    s1=s1+Form1->StringGrid1->Cells[i][j]+";";
   }
  }
  s2="";
  for(i=1;i<s1.Length();i++)
  {
   s2=s2+s1[i];
  }
  if(j==0)
  {
   Form1->Memo1->Lines->Add(s2);
  }
  else
  {
   if(n==1)
   {
    if(Form1->StringGrid1->Cells[Form1->StringGrid1->Col][j]!=Form1->Edit2->Text)
    {
     Form1->Memo1->Lines->Add(s2);
    }
   }
   if(n==2)
   {
    if(Form1->StringGrid1->Cells[Form1->StringGrid1->Col][j]==Form1->Edit2->Text)
    {
     Form1->Memo1->Lines->Add(s2);
    }
   }
  }
 }
 Form1->Memo1->Lines->SaveToFile("ONE.txt");
}



//---------------------------------------------------



void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
 readdata();
}

void __fastcall TForm1::BitBtn9Click(TObject *Sender)
{
 fuzzysets();
}

void __fastcall TForm1::BitBtn19Click(TObject *Sender)
{
 int j;
 if(Form1->StringGrid1->Row>0)
 {
  cleargraphic();
  fuzzy(0);
  fuzzy(1);
  showimage();
 }
 else
 {
  cleargraphic();
  for(j=1;j<Form1->StringGrid1->RowCount-1;j++)
  {
   Form1->StringGrid1->Row=j;
   if(j==1)
   {
    fuzzy(0);
    fuzzy(2);
   }
   else
   {
    fuzzy(2);
   }
  }
  showimage();
 }
}

void __fastcall TForm1::BitBtn17Click(TObject *Sender)
{
 outdata(1);
}

void __fastcall TForm1::BitBtn18Click(TObject *Sender)
{
 outdata(2);
}

void __fastcall TForm1::StringGrid1DblClick(TObject *Sender)
{
 if(Form1->StringGrid1->Row==Form1->StringGrid1->RowCount-1)
 {
  if(Form1->StringGrid1->Cells[Form1->StringGrid1->Col][Form1->StringGrid1->RowCount-1]!="+")
  {
   Form1->StringGrid1->Cells[Form1->StringGrid1->Col][Form1->StringGrid1->RowCount-1]="+";
  }
  else
  {
   Form1->StringGrid1->Cells[Form1->StringGrid1->Col][Form1->StringGrid1->RowCount-1]="";
  }
 }
 if(Form1->StringGrid1->Row==0)
 {
  if(Form1->StringGrid1->ColWidths[Form1->StringGrid1->Col]==120)
  {
   Form1->StringGrid1->ColWidths[Form1->StringGrid1->Col]=420;
  }
  else
  {
   Form1->StringGrid1->ColWidths[Form1->StringGrid1->Col]=120;
  }
 }
}

void __fastcall TForm1::StringGrid2DblClick(TObject *Sender)
{
 if(Form1->StringGrid2->Row==Form1->StringGrid2->RowCount-1)
 {
  if(Form1->StringGrid2->ColWidths[Form1->StringGrid2->Col]==120)
  {
   Form1->StringGrid2->ColWidths[Form1->StringGrid2->Col]=420;
  }
  else
  {
   Form1->StringGrid2->ColWidths[Form1->StringGrid2->Col]=120;
  }
 }
 else
 {

 }
}

void __fastcall TForm1::Image1DblClick(TObject *Sender)
{
 hideimage();
}





