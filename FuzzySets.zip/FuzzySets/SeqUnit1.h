//---------------------------------------------------------------------------

#ifndef SeqUnit1H
#define SeqUnit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TMemo *Memo1;
        TStringGrid *StringGrid1;
        TBitBtn *BitBtn1;
        TStringGrid *StringGrid2;
        TImage *Image1;
        TEdit *Edit1;
        TEdit *Edit2;
        TEdit *Edit3;
        TBitBtn *BitBtn9;
        TStringGrid *StringGrid3;
        TBitBtn *BitBtn17;
        TBitBtn *BitBtn18;
        TBitBtn *BitBtn19;
        void __fastcall BitBtn1Click(TObject *Sender);
        void __fastcall StringGrid2DblClick(TObject *Sender);
        void __fastcall Image1DblClick(TObject *Sender);
        void __fastcall BitBtn9Click(TObject *Sender);
        void __fastcall StringGrid1DblClick(TObject *Sender);
        void __fastcall BitBtn17Click(TObject *Sender);
        void __fastcall BitBtn18Click(TObject *Sender);
        void __fastcall BitBtn19Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
